const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { spawn } = require("node:child_process");
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  Menu,
  protocol,
  shell,
} = require("electron");
const { isLocalWorkspaceUrl, resolveWebsitePath, validateWebsiteUrl } = require("./lib.cjs");
const {
  listWorkspaceFiles,
  readWorkspaceFile,
  renameWorkspaceFile,
  resolveWorkspacePath,
  searchWorkspaceFiles,
  writeWorkspaceFile,
} = require("./workspace.cjs");
const { executionArguments, getRuntimeCommands, safeRuntimeEnvironment } = require("./workspace-runner.cjs");

const APP_SCHEME = "zervxhub";
const APP_HOST = "app";
const WORKSPACE_SMOKE_TEST = process.argv.includes("--workspace-smoke-test");
const SMOKE_TEST = process.argv.includes("--smoke-test") || WORKSPACE_SMOKE_TEST;
const MAX_RUN_OUTPUT = 100_000;
const MAX_RUN_MS = 120_000;
const runtimeProcesses = new Map();
const MIME_TYPES = new Map([
  [".css", "text/css; charset=utf-8"],
  [".html", "text/html; charset=utf-8"],
  [".ico", "image/x-icon"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".svg", "image/svg+xml"],
  [".webmanifest", "application/manifest+json; charset=utf-8"],
]);
const SECURITY_HEADERS = {
  "content-security-policy": "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; font-src 'self'; upgrade-insecure-requests",
  "referrer-policy": "no-referrer",
  "x-content-type-options": "nosniff",
  "x-frame-options": "DENY",
};

protocol.registerSchemesAsPrivileged([{
  scheme: APP_SCHEME,
  privileges: {
    standard: true,
    secure: true,
    supportFetchAPI: true,
    corsEnabled: true,
  },
}]);

app.setName("ZervxHub");
app.setAppUserModelId("com.zervxhub.desktop");

let mainWindow;
let configuredWebsiteOrigin;
let websiteDirectory;
let activeWorkspaceRoot;
let workspaceSmokeRoot;

function response(body, status, contentType = "text/plain; charset=utf-8") {
  return new Response(body, {
    status,
    headers: {
      ...SECURITY_HEADERS,
      "cache-control": "no-store",
      "content-type": contentType,
    },
  });
}

function isDiscordAuthorizationUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
      (url.hostname === "discord.com" ||
        url.hostname.endsWith(".discord.com") ||
        url.hostname === "discordapp.com" ||
        url.hostname.endsWith(".discordapp.com"));
  } catch {
    return false;
  }
}

function isAllowedInApp(value) {
  try {
    const url = new URL(value);
    if (url.protocol === `${APP_SCHEME}:`) return url.hostname === APP_HOST;
    return (configuredWebsiteOrigin && url.origin === configuredWebsiteOrigin) ||
      isDiscordAuthorizationUrl(value);
  } catch {
    return false;
  }
}

async function openExternalHttps(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return;
    await shell.openExternal(url.href);
  } catch (error) {
    dialog.showErrorBox("Unable to open link", error.message);
  }
}

async function serveAppRequest(request) {
  const url = new URL(request.url);
  if (url.hostname !== APP_HOST) return response("Not found", 404);
  if (request.method !== "GET" && request.method !== "HEAD") {
    return response("Method not allowed", 405);
  }

  if (/^\/v[12](?:\/|$)/.test(url.pathname)) {
    return response(
      JSON.stringify({ error: "The ZervxHub service is not configured for this desktop app." }),
      503,
      "application/json; charset=utf-8"
    );
  }

  const filePath = resolveWebsitePath(websiteDirectory, url.pathname);
  if (!filePath) return response("Not found", 404);

  try {
    const content = await fs.readFile(filePath);
    return new Response(request.method === "HEAD" ? null : content, {
      status: 200,
      headers: {
        ...SECURITY_HEADERS,
        "cache-control": "no-store",
        "content-type": MIME_TYPES.get(path.extname(filePath).toLowerCase()) ||
          "application/octet-stream",
      },
    });
  } catch (error) {
    if (error.code === "ENOENT" || error.code === "EISDIR") {
      return response("Not found", 404);
    }
    console.error("Could not read the packaged website asset.", error);
    return response("The packaged website asset could not be read.", 500);
  }
}

async function readWebsiteConfiguration() {
  const configPath = path.join(app.getPath("userData"), "config.json");
  let source;
  try {
    source = await fs.readFile(configPath, "utf8");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    source = JSON.stringify({ websiteUrl: "" }, null, 2);
    await fs.writeFile(configPath, `${source}\n`, { flag: "wx" });
  }

  let config;
  try {
    config = JSON.parse(source);
  } catch {
    throw new Error(`The desktop configuration file is not valid JSON: ${configPath}`);
  }
  if (
    !config ||
    Array.isArray(config) ||
    typeof config !== "object" ||
    Object.keys(config).some((key) => key !== "websiteUrl")
  ) {
    throw new Error(`The desktop configuration may contain only a websiteUrl field: ${configPath}`);
  }
  return validateWebsiteUrl(config.websiteUrl);
}

function attachNavigationGuards(window) {
  const contents = window.webContents;
  const handleNavigation = (event, target) => {
    if (isAllowedInApp(target)) return;
    event.preventDefault();
    void openExternalHttps(target);
  };
  contents.on("will-navigate", handleNavigation);
  contents.on("will-redirect", handleNavigation);
  contents.setWindowOpenHandler(({ url }) => {
    if (isAllowedInApp(url)) {
      void window.loadURL(url);
    } else {
      void openExternalHttps(url);
    }
    return { action: "deny" };
  });
  contents.on("will-attach-webview", (event) => event.preventDefault());
}

function assertWorkspaceSender(event) {
  if (!isLocalWorkspaceUrl(event.senderFrame?.url)) {
    throw new Error("Workspace access is available only from the local coding workspace.");
  }
}

function requireWorkspaceRoot() {
  if (!activeWorkspaceRoot) throw new Error("Open a project folder first.");
  return activeWorkspaceRoot;
}

function emitRunEvent(webContents, runId, type, data = {}) {
  if (!webContents.isDestroyed()) webContents.send("workspace:run-event", { runId, type, ...data });
}

function registerWorkspaceHandlers() {
  const handle = (channel, callback) => {
    ipcMain.handle(channel, async (event, ...args) => {
      assertWorkspaceSender(event);
      return callback(event, ...args);
    });
  };

  handle("workspace:choose-folder", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "Open a local project folder",
      properties: ["openDirectory"],
    });
    if (result.canceled || result.filePaths.length === 0) return null;
    activeWorkspaceRoot = await fs.realpath(result.filePaths[0]);
    return { name: path.basename(activeWorkspaceRoot), path: activeWorkspaceRoot };
  });
  handle("workspace:list-files", () => listWorkspaceFiles(requireWorkspaceRoot()));
  handle("workspace:read-file", (_event, filePath) => readWorkspaceFile(requireWorkspaceRoot(), filePath));
  handle("workspace:save-file", (_event, filePath, content) =>
    writeWorkspaceFile(requireWorkspaceRoot(), filePath, content));
  handle("workspace:create-file", (_event, filePath, content) =>
    writeWorkspaceFile(requireWorkspaceRoot(), filePath, content, { createOnly: true }));
  handle("workspace:rename-file", (_event, fromPath, toPath) =>
    renameWorkspaceFile(requireWorkspaceRoot(), fromPath, toPath));
  handle("workspace:search-files", (_event, query) => searchWorkspaceFiles(requireWorkspaceRoot(), query));
  handle("workspace:available-runtimes", () => getRuntimeCommands({
    packaged: app.isPackaged,
    resourcesPath: process.resourcesPath,
    appDirectory: __dirname,
  }).map(({ id, label }) => ({ id, label })));
  handle("workspace:run-file", async (event, filePath, runtimeId) => {
    const root = requireWorkspaceRoot();
    const runtime = getRuntimeCommands({
      packaged: app.isPackaged,
      resourcesPath: process.resourcesPath,
      appDirectory: __dirname,
    }).find((candidate) => candidate.id === runtimeId);
    if (!runtime) throw new Error("That local runtime is not available.");
    if (runtimeProcesses.size > 0) throw new Error("Stop the current run before starting another.");

    await readWorkspaceFile(root, filePath);
    const { fullPath } = await resolveWorkspacePath(root, filePath);
    const args = executionArguments(runtimeId, fullPath);
    const confirmation = await dialog.showMessageBox(mainWindow, {
      type: "warning",
      title: "Run local code?",
      message: `Run ${path.basename(filePath)} with ${runtime.label}?`,
      detail: "This code is not sandboxed. It runs with your Windows account permissions and may access or change files and use the network. Only run code you trust. ZervxHub does not add project secrets to its environment.",
      buttons: ["Run code", "Cancel"],
      defaultId: 1,
      cancelId: 1,
      noLink: true,
    });
    if (confirmation.response !== 0) return null;

    const runId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const child = spawn(runtime.command, args, {
      cwd: root,
      env: safeRuntimeEnvironment(),
      shell: false,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const processRecord = { child, webContents: event.sender, outputBytes: 0, timer: null };
    let finished = false;
    runtimeProcesses.set(runId, processRecord);

    const onOutput = (stream) => (chunk) => {
      if (!runtimeProcesses.has(runId)) return;
      const remaining = MAX_RUN_OUTPUT - processRecord.outputBytes;
      if (remaining <= 0) return;
      const text = chunk.toString("utf8").slice(0, remaining);
      processRecord.outputBytes += Buffer.byteLength(text, "utf8");
      emitRunEvent(event.sender, runId, "output", { stream, text });
      if (processRecord.outputBytes >= MAX_RUN_OUTPUT) {
        emitRunEvent(event.sender, runId, "output-limit", { text: "\nOutput limit reached; stopping the process.\n" });
        child.kill();
      }
    };
    child.stdout.on("data", onOutput("stdout"));
    child.stderr.on("data", onOutput("stderr"));
    child.once("error", (error) => {
      if (finished) return;
      finished = true;
      clearTimeout(processRecord.timer);
      runtimeProcesses.delete(runId);
      emitRunEvent(event.sender, runId, "exit", { error: error.message, code: null });
    });
    child.once("exit", (code, signal) => {
      if (finished) return;
      finished = true;
      clearTimeout(processRecord.timer);
      runtimeProcesses.delete(runId);
      emitRunEvent(event.sender, runId, "exit", { code, signal });
    });
    processRecord.timer = setTimeout(() => {
      if (runtimeProcesses.has(runId)) {
        emitRunEvent(event.sender, runId, "timeout", { text: "\nExecution time limit reached; stopping the process.\n" });
        child.kill();
      }
    }, MAX_RUN_MS);
    return { runId };
  });
  handle("workspace:stop-run", (event) => {
    let stopped = false;
    for (const [runId, processRecord] of runtimeProcesses) {
      if (processRecord.webContents !== event.sender) continue;
      processRecord.child.kill();
      stopped = true;
      emitRunEvent(event.sender, runId, "stopping");
    }
    return stopped;
  });
}

async function runSmokeTest(window) {
  if (!SMOKE_TEST) return;
  try {
    if (configuredWebsiteOrigin) {
      throw new Error("Smoke testing requires an unconfigured websiteUrl.");
    }
    if (WORKSPACE_SMOKE_TEST) {
      const result = await window.webContents.executeJavaScript(`(async () => {
        const runtimes = await window.zervxhubWorkspace.availableRuntimes();
        const modes = Object.keys(window.CodeMirror.modes);
        const editor = document.querySelector(".CodeMirror");
        const files = await window.zervxhubWorkspace.listFiles();
        const initial = await window.zervxhubWorkspace.readFile("src/main.js");
        await window.zervxhubWorkspace.createFile("src/created.ts", "export const value: number = 42;\\n");
        await window.zervxhubWorkspace.saveFile("src/main.js", "console.log('workspace-smoke-output');\\n");
        await window.zervxhubWorkspace.renameFile("src/main.js", "src/renamed.js");
        const saved = await window.zervxhubWorkspace.readFile("src/renamed.js");
        const matches = await window.zervxhubWorkspace.searchFiles("workspace-smoke-output");
        return {
          title: document.title,
          bridge: typeof window.zervxhubWorkspace.readFile === "function",
          editor: Boolean(editor && editor.getBoundingClientRect().height > 0),
          lineNumbers: Boolean(editor?.querySelector(".CodeMirror-linenumbers")),
          javascript: modes.includes("javascript"),
          python: modes.includes("python"),
          lua: modes.includes("lua"),
          htmlmixed: modes.includes("htmlmixed"),
          runtimes: runtimes.map((runtime) => runtime.id),
          files: files.files.map((file) => file.path),
          initial,
          saved,
          searchCount: matches.matches.length,
        };
      })()`, true);
      if (
        result.title !== "Coding Workspace | ZervxHub Developer Studio" ||
        !result.bridge ||
        !result.editor ||
        !result.lineNumbers ||
        !result.javascript ||
        !result.python ||
        !result.lua ||
        !result.htmlmixed ||
        !result.runtimes.includes("javascript") ||
        !result.files.includes("src/main.js") ||
        result.initial !== "console.log('workspace-smoke-initial');\n" ||
        result.saved !== "console.log('workspace-smoke-output');\n" ||
        result.searchCount !== 1
      ) {
        throw new Error(`Workspace packaged-app verification did not match expectations: ${JSON.stringify(result)}`);
      }
      const javascriptRuntime = getRuntimeCommands({
        packaged: app.isPackaged,
        resourcesPath: process.resourcesPath,
        appDirectory: __dirname,
      }).find((runtime) => runtime.id === "javascript");
      const smokeProcess = spawn(javascriptRuntime.command, [
        path.join(activeWorkspaceRoot, "src", "renamed.js"),
      ], {
        cwd: activeWorkspaceRoot,
        env: safeRuntimeEnvironment(),
        shell: false,
        windowsHide: true,
        stdio: ["ignore", "pipe", "pipe"],
      });
      const smokeOutput = await new Promise((resolve, reject) => {
        let stdout = "";
        let stderr = "";
        const timer = setTimeout(() => {
          smokeProcess.kill();
          reject(new Error("Bundled JavaScript runtime smoke test timed out."));
        }, 10_000);
        smokeProcess.stdout.on("data", (chunk) => { stdout += chunk.toString("utf8"); });
        smokeProcess.stderr.on("data", (chunk) => { stderr += chunk.toString("utf8"); });
        smokeProcess.once("error", (error) => {
          clearTimeout(timer);
          reject(error);
        });
        smokeProcess.once("exit", (code) => {
          clearTimeout(timer);
          if (code !== 0) reject(new Error(`Bundled JavaScript runtime exited ${code}: ${stderr}`));
          else resolve(stdout);
        });
      });
      if (smokeOutput.trim() !== "workspace-smoke-output") {
        throw new Error("Bundled JavaScript runtime did not emit the expected output.");
      }
      await fs.rm(workspaceSmokeRoot, { recursive: true, force: true });
      workspaceSmokeRoot = null;
      activeWorkspaceRoot = null;
      console.log("ZervxHub packaged coding-workspace smoke test passed.", JSON.stringify(result));
      app.exit(0);
      return;
    }
    const result = await window.webContents.executeJavaScript(`(async () => {
      const response = await fetch("/v2/auth/status");
      const data = await response.json();
      return { title: document.title, status: response.status, error: data.error };
    })()`, true);
    if (
      result.title !== "ZervxHub | Roblox developer licensing" ||
      result.status !== 503 ||
      result.error !== "The ZervxHub service is not configured for this desktop app."
    ) {
      throw new Error("Packaged app content or unavailable-service response did not match expectations.");
    }
    console.log("ZervxHub packaged-app smoke test passed.");
    app.exit(0);
  } catch (error) {
    console.error("ZervxHub packaged-app smoke test failed.", error);
    if (workspaceSmokeRoot) {
      await fs.rm(workspaceSmokeRoot, { recursive: true, force: true }).catch(() => {});
      workspaceSmokeRoot = null;
    }
    app.exit(1);
  }
}

async function prepareWorkspaceSmokeProject() {
  workspaceSmokeRoot = await fs.mkdtemp(path.join(os.tmpdir(), "zervxhub-workspace-smoke-"));
  await fs.mkdir(path.join(workspaceSmokeRoot, "src"));
  await fs.writeFile(
    path.join(workspaceSmokeRoot, "src", "main.js"),
    "console.log('workspace-smoke-initial');\n",
    "utf8"
  );
  activeWorkspaceRoot = workspaceSmokeRoot;
}

async function start() {
  try {
    configuredWebsiteOrigin = await readWebsiteConfiguration();
  } catch (error) {
    dialog.showErrorBox("ZervxHub configuration error", error.message);
    app.exit(1);
    return;
  }

  websiteDirectory = app.isPackaged
    ? path.join(process.resourcesPath, "website")
    : path.join(__dirname, "..", "website");
  const appIconPath = app.isPackaged
    ? path.join(process.resourcesPath, "zervxhub.ico")
    : path.join(__dirname, "assets", "zervxhub.ico");
  if (WORKSPACE_SMOKE_TEST) await prepareWorkspaceSmokeProject();
  await protocol.handle(APP_SCHEME, serveAppRequest);
  Menu.setApplicationMenu(null);

  mainWindow = new BrowserWindow({
    width: 1180,
    height: 800,
    minWidth: 360,
    minHeight: 540,
    autoHideMenuBar: true,
    icon: appIconPath,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      webviewTag: false,
      devTools: !app.isPackaged,
    },
  });
  attachNavigationGuards(mainWindow);
  registerWorkspaceHandlers();
  mainWindow.webContents.on("did-finish-load", () => void runSmokeTest(mainWindow));

  const startUrl = configuredWebsiteOrigin
    ? `${configuredWebsiteOrigin}/`
    : `${APP_SCHEME}://${APP_HOST}${WORKSPACE_SMOKE_TEST ? "/coding-workspace" : "/"}`;
  try {
    await mainWindow.loadURL(startUrl);
  } catch (error) {
    if (!configuredWebsiteOrigin) throw error;
    dialog.showErrorBox(
      "ZervxHub website unavailable",
      `The configured ZervxHub website could not be loaded. Check the network or clear websiteUrl in the desktop configuration file.\n\n${error.message}`
    );
    configuredWebsiteOrigin = null;
    await mainWindow.loadURL(`${APP_SCHEME}://${APP_HOST}/`);
  }
}

app.whenReady().then(start).catch((error) => {
  console.error("ZervxHub could not start.", error);
  dialog.showErrorBox("ZervxHub could not start", error.message);
  app.exit(1);
});

app.on("window-all-closed", () => app.quit());
