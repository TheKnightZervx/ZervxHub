const path = require("node:path");

const routeFiles = new Map([
  ["/", "index.html"],
  ["/pricing", "pricing.html"],
  ["/docs", "docs.html"],
  ["/support", "support.html"],
  ["/policies", "policies.html"],
  ["/dashboard", "dashboard.html"],
  ["/admin", "admin.html"],
  ["/studio", "studio.html"],
  ["/documentation-generator", "documentation-generator.html"],
  ["/security-scanner", "security-scanner.html"],
  ["/coding-workspace", "coding-workspace.html"],
  ["/offline", "offline.html"],
]);

function validateWebsiteUrl(value) {
  if (value === undefined || value === "") return null;
  if (typeof value !== "string") throw new Error("websiteUrl must be an HTTPS origin.");

  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("websiteUrl must be an HTTPS origin.");
  }

  if (
    url.protocol !== "https:" ||
    !url.hostname ||
    url.username ||
    url.password ||
    url.pathname !== "/" ||
    url.search ||
    url.hash
  ) {
    throw new Error("websiteUrl must be an HTTPS origin without a path, credentials, query, or fragment.");
  }
  return url.origin;
}

function isLocalWorkspaceUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "zervxhub:" &&
      url.hostname === "app" &&
      ["/coding-workspace", "/coding-workspace.html"].includes(url.pathname);
  } catch {
    return false;
  }
}

function resolveWebsitePath(root, urlPath) {
  if (typeof urlPath !== "string" || !urlPath.startsWith("/") || urlPath.includes("\\")) {
    return null;
  }

  let decodedPath;
  try {
    decodedPath = decodeURIComponent(urlPath);
  } catch {
    return null;
  }
  if (decodedPath.includes("\\") || decodedPath.includes("\0")) return null;

  const relativePath = routeFiles.get(decodedPath) || decodedPath.slice(1);
  const resolvedRoot = path.resolve(root);
  const resolvedPath = path.resolve(resolvedRoot, relativePath);
  const relativeToRoot = path.relative(resolvedRoot, resolvedPath);
  if (
    relativeToRoot === ".." ||
    relativeToRoot.startsWith(`..${path.sep}`) ||
    path.isAbsolute(relativeToRoot)
  ) {
    return null;
  }
  return resolvedPath;
}

module.exports = { isLocalWorkspaceUrl, resolveWebsitePath, validateWebsiteUrl };
