const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { app, BrowserWindow } = require("electron");

const sizes = [16, 32, 48, 256];
const pngSignature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const assetsDirectory = path.join(__dirname, "..", "assets");

function makeIcon(pngImages) {
  const directory = Buffer.alloc(6 + sizes.length * 16);
  directory.writeUInt16LE(0, 0);
  directory.writeUInt16LE(1, 2);
  directory.writeUInt16LE(sizes.length, 4);

  let nextImageOffset = directory.length;
  for (let index = 0; index < sizes.length; index += 1) {
    const size = sizes[index];
    const png = pngImages[index];
    const entryOffset = 6 + index * 16;
    directory.writeUInt8(size === 256 ? 0 : size, entryOffset);
    directory.writeUInt8(size === 256 ? 0 : size, entryOffset + 1);
    directory.writeUInt8(0, entryOffset + 2);
    directory.writeUInt8(0, entryOffset + 3);
    directory.writeUInt16LE(1, entryOffset + 4);
    directory.writeUInt16LE(32, entryOffset + 6);
    directory.writeUInt32LE(png.length, entryOffset + 8);
    directory.writeUInt32LE(nextImageOffset, entryOffset + 12);
    nextImageOffset += png.length;
  }
  return Buffer.concat([directory, ...pngImages]);
}

async function renderIcons() {
  const source = await fs.readFile(path.join(assetsDirectory, "zervxhub.svg"));
  const svgUrl = `data:image/svg+xml;base64,${source.toString("base64")}`;
  const window = new BrowserWindow({
    show: false,
    width: 256,
    height: 256,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  try {
    await window.loadURL("data:text/html,<html><body></body></html>");
    const pngImages = [];
    for (const size of sizes) {
      const dataUrl = await window.webContents.executeJavaScript(`(async () => {
        const image = new Image();
        image.src = ${JSON.stringify(svgUrl)};
        await image.decode();
        const canvas = document.createElement("canvas");
        canvas.width = ${size};
        canvas.height = ${size};
        canvas.getContext("2d").drawImage(image, 0, 0, ${size}, ${size});
        return canvas.toDataURL("image/png");
      })()`, true);
      const png = Buffer.from(dataUrl.split(",")[1], "base64");
      if (!png.subarray(0, pngSignature.length).equals(pngSignature)) {
        throw new Error(`Chromium did not render a valid ${size}px PNG icon.`);
      }
      pngImages.push(png);
      if (size === 256) {
        await fs.writeFile(path.join(os.tmpdir(), "zervxhub-icon-preview.png"), png);
      }
    }

    await fs.writeFile(
      path.join(assetsDirectory, "zervxhub.ico"),
      makeIcon(pngImages)
    );
    console.log("Generated zervxhub.ico with 16, 32, 48, and 256px representations.");
  } finally {
    window.destroy();
  }
}

app.whenReady().then(renderIcons).then(
  () => app.quit(),
  (error) => {
    console.error("Could not generate the ZervxHub Windows icon.", error);
    app.exit(1);
  }
);
